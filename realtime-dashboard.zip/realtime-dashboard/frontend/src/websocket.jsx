// ✅ frontend/src/utils/websockets.js
import { io } from "socket.io-client";

let socket;

export function connectWebSocket(onMessage) {
  // Create socket connection (must match backend port)
  socket = io("http://localhost:4000", {
    transports: ["websocket"], // enforce websocket only
    reconnectionAttempts: 5,
    reconnectionDelay: 2000,
  });

  // Connection events
  socket.on("connect", () => {
    console.log("🟢 Connected to WebSocket server:", socket.id);
  });

  socket.on("disconnect", (reason) => {
    console.warn("🔴 Disconnected:", reason);
  });

  socket.on("connect_error", (err) => {
    console.error("❌ WebSocket error:", err.message);
  });

  // Receive real-time updates
  socket.on("eventUpdate", (data) => {
    console.log("📡 Event update received:", data);
    onMessage(data);
  });

  return socket;
}

export function sendEvent(eventData) {
  if (socket && socket.connected) {
    socket.emit("sendEvent", eventData);
  } else {
    console.warn("⚠️ Socket not connected, cannot send event.");
  }
}
