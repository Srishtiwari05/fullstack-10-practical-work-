import React from "react";
import Dashboard from "./components/Dashboard";

export default function App() {
  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>📊 Real-Time Analytics Dashboard</h1>
      <Dashboard />
    </div>
  );
}
