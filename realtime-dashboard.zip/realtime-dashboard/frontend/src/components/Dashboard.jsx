// frontend/src/components/Dashboard.jsx
import React, { useEffect, useState } from "react";
import io from "socket.io-client";
import Charts from "./Charts";
import { connectWebSocket } from "../websocket.jsx";
const socket = io("http://localhost:4000"); // ✅ same as backend port

export default function Dashboard() {
  const [metrics, setMetrics] = useState({
    activeUsers: 0,
    eventsPerSec: 0,
    timestamp: null,
  });

  useEffect(() => {
    socket.on("connect", () => console.log("✅ Connected to Socket.io server"));

    socket.on("eventUpdate", (event) => {
      console.log("📩 New event received:", event);

      // Update dashboard metrics
      setMetrics((prev) => ({
        activeUsers: prev.activeUsers + 1,
        eventsPerSec: prev.eventsPerSec + 1,
        timestamp: new Date().toISOString(),
      }));
    });

    return () => {
      socket.off("eventUpdate");
    };
  }, []);

  return (
    <div className="dashboard">
      <h1>Real-Time Dashboard</h1>
      <h2>Active Users: {metrics.activeUsers}</h2>
      <h3>Events/sec: {metrics.eventsPerSec}</h3>

      <Charts metrics={metrics} />
    </div>
  );
}
