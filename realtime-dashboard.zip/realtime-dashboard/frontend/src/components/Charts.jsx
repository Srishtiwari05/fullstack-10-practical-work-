// frontend/src/components/Charts.jsx
import { Line } from "react-chartjs-2";
import { useEffect, useState } from "react";
import {
  Chart as ChartJS,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Title,
  Tooltip,
  Legend
);

export default function Charts({ metrics }) {
  const [dataPoints, setDataPoints] = useState([]);

  useEffect(() => {
    // Every time backend emits new metrics
    if (metrics && typeof metrics.activeUsers === "number") {
      const now = new Date();
      setDataPoints((prev) => [
        ...prev.slice(-19), // keep last 20 points
        { time: now.toLocaleTimeString(), value: metrics.activeUsers },
      ]);
    }
  }, [metrics]);

  const data = {
    labels: dataPoints.map((p) => p.time),
    datasets: [
      {
        label: "Active Users (last 60s)",
        data: dataPoints.map((p) => p.value),
        borderColor: "rgba(75,192,192,1)",
        borderWidth: 2,
        tension: 0.3,
        pointRadius: 0,
      },
    ],
  };

  const options = {
    responsive: true,
    animation: false,
    plugins: {
      legend: { display: true },
      title: { display: true, text: "Real-Time Active Users" },
      tooltip: { mode: "index", intersect: false },
    },
    scales: {
      x: { title: { display: true, text: "Time" } },
      y: { title: { display: true, text: "Users" }, beginAtZero: true },
    },
  };

  return (
    <div style={{ width: "100%", height: "400px" }}>
      <Line data={data} options={options} />
    </div>
  );
}
