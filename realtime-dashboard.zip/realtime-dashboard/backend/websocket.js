import { Server } from "socket.io";
import Event from "./models/Event.js";
import { updateAggregates } from "./utils/aggregates.js";

export function setupWebSocket(server) {
  // ✅ Initialize socket.io server
  const io = new Server(server, {
    cors: {
      origin: "http://localhost:5173", // frontend URL
      methods: ["GET", "POST"],
    },
  });

  io.on("connection", (socket) => {
    console.log("🟢 Client connected:", socket.id);

    // When client manually sends an event (optional)
    socket.on("sendEvent", async (data) => {
      try {
        const event = new Event(data);
        await event.save();

        const agg = updateAggregates(event);

        // ✅ Broadcast update to all connected dashboards
        io.emit("eventUpdate", {
          activeUsers: agg.activeUsers,
          eventsPerSec: agg.eventsPerSec,
          timestamp: new Date(),
        });
      } catch (err) {
        console.error("❌ WebSocket event error:", err.message);
      }
    });

    socket.on("disconnect", () => {
      console.log("🔴 Client disconnected:", socket.id);
    });
  });

  console.log("🌐 Socket.io WebSocket server ready");
  return io;
}
