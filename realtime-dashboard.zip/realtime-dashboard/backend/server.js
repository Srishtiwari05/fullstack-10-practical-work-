import express from "express";
import http from "http";
import mongoose from "mongoose";
import dotenv from "dotenv";
import cors from "cors";
import { Server } from "socket.io";
import Event from "./models/Event.js";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// ✅ MongoDB connection
mongoose
  .connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("✅ MongoDB connected"))
  .catch((err) => console.error("❌ MongoDB connection error:", err));

// === Create HTTP server ===
const server = http.createServer(app);

// === Socket.IO setup ===
const io = new Server(server, {
  cors: {
    origin: "http://localhost:3000", // match frontend
    methods: ["GET", "POST"],
  },
});

// === Aggregates (in-memory rolling window) ===
let eventWindow = [];
let activeUsersSet = new Set();

// Helper to recalc aggregates
function computeAggregates() {
  const now = Date.now();
  // Keep last 60s window
  eventWindow = eventWindow.filter((e) => now - e.timestamp < 60000);

  const activeUsers = activeUsersSet.size;
  const eventsPerSec = eventWindow.length / 60;

  return { activeUsers, eventsPerSec };
}

// === WebSocket events ===
io.on("connection", (socket) => {
  console.log("🔌 Client connected:", socket.id);
  socket.emit("eventUpdate", computeAggregates()); // send initial data

  socket.on("disconnect", () => {
    console.log("❌ Client disconnected:", socket.id);
  });
});

// === REST API: Event Ingestion ===
app.post("/api/events", async (req, res) => {
  try {
    const { userId, route, action, metadata } = req.body;

    if (!userId || !route || !action) {
      return res.status(400).json({ success: false, error: "Missing required fields" });
    }

    const event = new Event({
      timestamp: new Date(),
      userId,
      route,
      action,
      metadata,
    });

    await event.save();

    // Update rolling window
    eventWindow.push({ timestamp: Date.now(), userId });
    activeUsersSet.add(userId);

    const agg = computeAggregates();

    // 🔥 Emit live updates to all clients
    io.emit("eventUpdate", agg);

    res.status(201).json({ success: true, message: "Event logged successfully", data: agg });
  } catch (error) {
    console.error("Error saving event:", error);
    res.status(500).json({ success: false, error: "Internal server error" });
  }
});

// === Health check ===
app.get("/health", (req, res) => res.send("✅ Server is healthy"));

// === Start server ===
const PORT = process.env.PORT || 4000;
server.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
