let recentEvents = [];

export function updateAggregates(event) {
  const now = Date.now();
  recentEvents.push(event);
  // keep only last 60 seconds
  recentEvents = recentEvents.filter(e => now - new Date(e.timestamp).getTime() < 60000);

  const activeUsers = new Set(recentEvents.map(e => e.userId)).size;
  const eventsPerSecond = recentEvents.length / 60;

  const topRoutes = {};
  recentEvents.forEach(e => {
    topRoutes[e.route] = (topRoutes[e.route] || 0) + 1;
  });

  return { timestamp: now, activeUsers, eventsPerSecond, topRoutes };
}
